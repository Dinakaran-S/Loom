process.env.NODE_ENV = "test";
process.env.JWT_ACCESS_SECRET = "test-access-secret";
process.env.JWT_REFRESH_SECRET = "test-refresh-secret";
process.env.CORS_ORIGIN = "http://localhost:5173";
process.env.DB_HOST = "localhost";
process.env.DB_USER = "test";
process.env.DB_NAME = "test";
